tic
clc
clear all
for i=0:24
    img = strcat('C:\Users\PUTUL SIDDHARTH\Desktop\images/',num2str(i),'.jpg');     
    if i==0
        % Loading query image
        query_image = imread(img);
        % Extracting colour planes of query image
        [row_q,col_q]=size(query_image);
    else
        I=imread(img);
        [row,col]=size(I);
        dist = asinh(sum(abs(row-row_q)+abs(col-col_q)));
        data = [i,dist];
        dlmwrite('C:\Users\PUTUL SIDDHARTH\Desktop\labt.csv',data,'-append')
    end
end
file_data = readtable('C:\Users\PUTUL SIDDHARTH\Desktop\labt.csv');
sorted = sortrows(file_data,2);
output = table(sorted(1:6,1),sorted(1:6,2));
output.Properties.VariableNames = {'ImageName','Distance'};
subplot(3,3,2)
img = imread('C:\Users\PUTUL SIDDHARTH\Desktop\images/0.jpg');
imshow(img)
for k=1:6
    img=strcat('C:\Users\PUTUL SIDDHARTH\Desktop\images/',num2str(output(k,1).ImageName.Var1),'.jpg');
    subplot(3,3,k+3)
    I=imread(img);
    imshow(I)
end
output
tp=2;
fn=4;
fp=4;
tn=14;
precision=tp/(tp+fp);
recall=tp/(tp+fn);
fprintf("Precision %f\n:-",precision);
fprintf("Recall %f\n:-",recall);
toc
