tic
clc
distance_vector = [1 3]
temp_data = zeros(20,128);

for i=0:24
    img = strcat('C:\Users\PUTUL SIDDHARTH\Desktop\images/',num2str(i),'.jpg');
    image = imread(img);
    correlogram_vector=color_auto_correlogram(image,distance_vector);
    
    if i==0
        query_vector = correlogram_vector';
    else
        dist = sum((abs(correlogram_vector') - abs(query_vector)) .^2);
        data = [i,correlogram_vector',dist];
        dlmwrite('C:\Users\PUTUL SIDDHARTH\Desktop\lab16.csv',data,'-append')
    end
end

file_data = readtable('C:\Users\PUTUL SIDDHARTH\Desktop\lab16.csv');
sorted = sortrows(file_data,130);
output = table(sorted(1:6,1),sorted(1:6,130));
output.Properties.VariableNames = {'ImageName','Distance'};
subplot(3,3,2)
img = imread('C:\Users\PUTUL SIDDHARTH\Desktop\images/0.jpg');
imshow(img)
for k=1:6
    img=strcat('C:\Users\PUTUL SIDDHARTH\Desktop\images/',num2str(output(k,1).ImageName.Var1),'.jpg');
    subplot(3,3,k+3)
    I=imread(img);
    imshow(I)
end
output
toc



